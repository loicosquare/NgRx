export interface Books {
  id: number;
  name: string;
  author: string;
  cost: number;
}
