export interface Appstate {
  apiStatus: string;
  apiResponseMessage: string;
}
